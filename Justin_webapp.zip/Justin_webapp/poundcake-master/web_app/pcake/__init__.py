#! /usr/bin/env python

from flask import Flask

from pcake.views import app