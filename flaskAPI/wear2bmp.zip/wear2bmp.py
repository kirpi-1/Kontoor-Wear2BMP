import os
from flask import Flask, flash, request, redirect, url_for, send_from_directory
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = './tmp'
ALLOWED_EXTENSIONS = {'png','jpg','jpeg','zip','7z'};

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER;


def allowed_file(filename):
    return '.' in filename and \
        filename.rsplit('.',1)[1].lower() in ALLOWED_EXTENSIONS

        

@app.route("/")
def index():
    return redirect("./index.html")

@app.route("/hello")
def helloWorld():
    return "Hello World"

@app.route("/GETtest")
def getTest():
    return "successfully pinged"

@app.route("/POSTtest",methods=['POST'])
def postTest():
    print("received POST")
    files = request.files.getlist('images');
    ip = request.remote_addr;
    if not os.path.isdir(app.config['UPLOAD_FOLDER'] + '/' + ip):
        os.mkdir(app.config['UPLOAD_FOLDER'] + '/' + ip);
    for f in files:
        name = secure_filename(f.filename);
        name = os.path.basename(name);
        f.save(os.path.join(app.config['UPLOAD_FOLDER'],ip,name));
    return "sucessfully uploaded"
@app.route('/uploader',methods=['GET','POST'])
def upload_file():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        # if user does not select file, broswer also submit an empty part without filename
        if file.filename =='':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            ip = request.remote_addr;            
            if not os.path.isdir(app.config['UPLOAD_FOLDER']+'/'+ip):
                os.mkdir('tmp/'+ip);
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER']+'/'+ip,filename));
            #return redirect(url_for('uploaded_file',filename=filename))
            return 'file uploaded successfully'
        return


@app.route("/filenames", methods=["GET"])
def get_filenames():
    filenames = os.listdir("uploads/")

    #modify_time_sort = lambda f: os.stat("uploads/{}".format(f)).st_atime

    def modify_time_sort(file_name):
        file_path = "uploads/{}".format(file_name)
        file_stats = os.stat(file_path)
        last_access_time = file_stats.st_atime
        return last_access_time

    filenames = sorted(filenames, key=modify_time_sort)
    return_dict = dict(filenames=filenames)
    return jsonify(return_dict)


if __name__ == '__main__':
    app.run(host='0.0.0.0',port='5000')
      
